from twython import Twython,TwythonError,TwythonRateLimitError
import csv
import unicodedata as s
import json
import time
from pymongo import MongoClient
import reverse_geocoder as rg
import geopy
import plotly.plotly as py
import plotly.graph_objs as go
import matplotlib.pyplot as plt
import nltk
from nltk.probability import FreqDist
from itertools import groupby
import dictionary 
import pylab
import numpy as np
from nltk.corpus import stopwords

api_key = 'use own'
api_secret = 'use own'
access_token = 'use own'
access_token_secret = 'use own'
	
twitter = Twython(api_key,api_secret,access_token,access_token_secret)

client = MongoClient()
db = client.ojasdb
col1=db.collec1#for pananma papers
col2=db.collec2#for fake news
stpwrds=set(stopwords.words('english'))
'''
timeline = twitter.search(q='#PanamaPapers',count=100,lang='en',include_entities='True',result_type="mixed")
if timeline:
	for var in range(1,120):
		for v in timeline['statuses']:		
			latest=v['id']
			col1.insert(v)
		latest=latest-1
		timeline = twitter.search(q='#PanamaPapers',count=100,lang='en',max_id=latest,result_type="mixed")
'''
'''
timeline = twitter.search(q='#FakeNews',count=100,lang='en',include_entities='True',result_type="mixed")
if timeline:
	for var in range(1,120):
		for v in timeline['statuses']:		
			latest=v['id']
			col2.insert(v)
		latest=latest-1
		timeline = twitter.search(q='#FakeNews',count=100,lang='en',max_id=latest,result_type="mixed")
'''

words=[]
e=col1.find()
for oj in e:
	loc=oj['text']
	text=[]
	text=text+list(loc.split())
	for var in text:
		low=var.lower()
		if low not in list(stpwrds):
			words.append(var)
fd=FreqDist(words)
fd.plot(20)

words=[]
e=col2.find()
for oj in e:
	loc=oj['text']
	text=[]
	text=text+list(loc.split())
	for var in text:
		low=var.lower()
		if low not in list(stpwrds):
			words.append(var)
fd=FreqDist(words)
fd.plot(20)

