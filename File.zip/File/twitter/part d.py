from twython import Twython,TwythonError,TwythonRateLimitError
import csv
import json
import time
from pymongo import MongoClient
import reverse_geocoder as rg
import geopy
import plotly.plotly as py
import plotly.graph_objs as go
import matplotlib.pyplot as plt

api_key = 'use own'
api_secret = 'use own'
access_token = 'use own'
access_token_secret = 'use own'	
	
twitter = Twython(api_key,api_secret,access_token,access_token_secret)

client = MongoClient()
db = client.ojasdb
col1=db.collec1#for panama papers
col2=db.collec2#for fake news
'''
timeline = twitter.search(q='#PanamaPapers',count=100,lang='en',include_entities='True',result_type="mixed")
if timeline:
	for var in range(1,120):
		for v in timeline['statuses']:		
			latest=v['id']
			col1.insert(v)
		latest=latest-1
		timeline = twitter.search(q='#PanamaPapers',count=100,lang='en',max_id=latest,result_type="mixed")
'''
'''
timeline = twitter.search(q='#FakeNews',count=100,lang='en',include_entities='True',result_type="mixed")
if timeline:
	for var in range(1,120):
		for v in timeline['statuses']:		
			latest=v['id']
			col2.insert(v)
		latest=latest-1
		timeline = twitter.search(q='#FakeNews',count=100,lang='en',max_id=latest,include_entities='True',result_type="mixed")
'''
a=['hashtag','url','media','user_mention']
b=[0,0,0,0]
e=col1.find()
for oj in e:
	if oj['entities']['hashtags']!=[ ]:
		b[0]=b[0]+1
	if oj['entities']['urls']!=[ ]:
		b[1]=b[1]+1
	if oj['entities'].get('media'):
		b[2]=b[2]+1
	if oj['entities']['user_mentions']!=[ ]:
		b[3]=b[3]+1
plt.pie(b,labels=a)
plt.title('Amount of diiferent type of data in tweets for #PanamaPapers')
plt.show()




a=['hashtag','url','media','user_mention']
b=[0,0,0,0]
e=col2.find()
for oj in e:
	if oj['entities']['hashtags']!=[ ]:
		b[0]=b[0]+1
	if oj['entities']['urls']!=[ ]:
		b[1]=b[1]+1
	if oj['entities'].get('media'):
		b[2]=b[2]+1
	if oj['entities']['user_mentions']!=[ ]:
		b[3]=b[3]+1
plt.pie(b,labels=a)
plt.title('Amount of diiferent type of data in tweets for #FakeNews')
plt.show()
