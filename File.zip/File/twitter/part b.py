from twython import Twython,TwythonError,TwythonRateLimitError
import pylab
import math
import iso3166
from iso3166 import countries
import pycountry
from pytz import country_timezones
import csv
import json
import time
from pymongo import MongoClient
import reverse_geocoder as rg
import geopy
import plotly.plotly as py
import plotly.graph_objs as go
import matplotlib.pyplot as plt

api_key = 'use own'
api_secret = 'use own'
access_token = 'use own'
access_token_secret = 'use own'	
twitter = Twython(api_key,api_secret,access_token,access_token_secret)

client = MongoClient()
db = client.ojasdb

col1=db.collec1#for panama papers
col2=db.collec2#for fake news
'''
timeline = twitter.search(q='#PanamaPapers',count=100,lang='en',include_entities='True',result_type="mixed")
if timeline:
	for var in range(1,120):
		for v in timeline['statuses']:		
			latest=v['id']
			col1.insert(v)
		latest=latest-1
		timeline = twitter.search(q='#PanamaPapers',count=100,lang='en',max_id=latest,result_type="mixed")
'''
'''
timeline = twitter.search(q='#Fakenews',count=100,lang='en',include_entities='True',result_type="mixed")
if timeline:
	for var in range(1,120):
		for v in timeline['statuses']:		
			latest=v['id']
			col2.insert(v)
		latest=latest-1
		timeline = twitter.search(q='#Fakenews',count=100,lang='en',max_id=latest,result_type="mixed")
'''
a=[]
b=[]
exp=[]
timezone_cntry={}
for cntry in country_timezones:
	timezones=country_timezones[cntry]
	for timezone in timezones:
		timezone_cntry[timezone]=cntry
e=col1.find()
for oj in e:
	loc=oj['user']['time_zone']
	if loc:
		loc=loc.encode('ascii')
		if loc in timezone_cntry.keys():
			cntry_code=timezone_cntry[loc]
			cntry_arr=countries.get(cntry_code)
			cntry_name=cntry_arr[0]
			cntry_name=cntry_name.encode('ascii')
			if cntry_name in a:
				i=0
				for v in a:
					if v==cntry_name:
						pos=i
					else:
						i=i+1
				b[pos]=b[pos]+1
			else:
				a.append(cntry_name)
				b.append(1)
				exp.append(.09)
count=0
e=col1.find()
for oj in e:
	if oj['user']['geo_enabled']==True:
		count=count+1	
print 'Number of geo enabled tweets with #panamapapers is: ',count
plt.title('Countries from which tweet was tweeted')
plt.pie(b,labels=a,explode=exp,radius=.5,labeldistance=.8)
plt.axis('equal')
plt.title('Percentage of tweets with #panamapapers in different countries')
plt.show()



a=[]
b=[]
exp=[]
timezone_cntry={}
for cntry in country_timezones:
	timezones=country_timezones[cntry]
	for timezone in timezones:
		timezone_cntry[timezone]=cntry
e=col2.find()
for oj in e:
	loc=oj['user']['time_zone']
	if loc:
		loc=loc.encode('ascii')
		if loc in timezone_cntry.keys():
			cntry_code=timezone_cntry[loc]
			cntry_arr=countries.get(cntry_code)
			cntry_name=cntry_arr[0]
			cntry_name=cntry_name.encode('ascii')
			if cntry_name in a:
				i=0
				for v in a:
					if v==cntry_name:
						pos=i
					else:
						i=i+1
				b[pos]=b[pos]+1
			else:
				a.append(cntry_name)
				b.append(1)
				exp.append(.09)
count=0
e=col2.find()
for oj in e:
	if oj['user']['geo_enabled']==True:
		count=count+1	
print 'Number of geo enabled tweets with #fakenews is: ',count
plt.title('Countries from which tweet was tweeted')
plt.pie(b,labels=a,explode=exp,radius=.5,labeldistance=.8)
plt.axis('equal')
plt.title('Percentage of tweets with #fakenews in different countries')
plt.show()
