from twython import Twython,TwythonError,TwythonRateLimitError
import csv
import json
import time
from pymongo import MongoClient
import reverse_geocoder as rg
import geopy
import plotly.plotly as py
import plotly.graph_objs as go
import matplotlib.pyplot as plt

api_key = 'use own'
api_secret = 'use own'
access_token = 'use own'
access_token_secret = 'use own'	
	
twitter = Twython(api_key,api_secret,access_token,access_token_secret)

timeline = twitter.get_user_timeline(user_id='101311381',count=100)
while timeline:
	for t in timeline:
		maxid=t['id']
	maxid=maxid-1
	tweet=twitter.show_status(id=maxid+1)
	print tweet['text']
	timeline = twitter.get_user_timeline(user_id='101311381',count=100,max_id=maxid)
maxid=maxid+1
tweet=twitter.show_status(id=maxid)
print tweet['text']
