import json
import facebook
import requests
import nltk
from nltk.probability import FreqDist
import matplotlib
import matplotlib.pyplot as plt

ids='1668362483197811'  
token='use own'
graph=facebook.GraphAPI(token)

words=[]
react=['Like','Love','Haha','Wow','Sad','angry']
b=[0,0,0,0,0,0]
posts=graph.get_connections(id=ids,connection_name='posts')
while(True):
	try:
		for p in posts['data']:
			p_id=p['id']
			post_msg=graph.get_object(id=p_id,fields='message')
			if post_msg.get(u'message'):	
				message=post_msg.get(u'message')
				words=words+list(p['message'].split())
		reactions=graph.get_connections(id=p_id,connection_name='reactions')
		while(True):
			try:
				for r in reactions['data']:	
					if r['type']=='LIKE':
						b[0]=b[0]+1
					if r['type']=='LOVE':
						b[1]=b[1]+1
					if r['type']=='HAHA':
						b[2]=b[2]+1
					if r['type']=='WOW':
						b[3]=b[3]+1
					if r['type']=='SAD':
						b[4]=b[4]+1
					if r['type']=='ANGRY':
						b[5]=b[5]+1
				reactions=requests.get(reactions['paging']['next']).json()
			except KeyError:
				break
		posts=requests.get(posts['paging']['next']).json()
	except KeyError:
		break
plt.pie(b,labels=react)
plt.title('Chart depicting count of reactions')
plt.show()
fd=FreqDist(words)
fd.plot(20)
