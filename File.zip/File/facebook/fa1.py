import matplotlib.pyplot as plt
import json
import facebook
import requests
import nltk
from nltk.probability import FreqDist
import matplotlib
import matplotlib.pyplot as plt
from itertools import groupby
from collections import Counter


graph=facebook.GraphAPI(token)
token='use own'
friends=graph.get_connections(id='me',connection_name='friends')
i=0
locale_list=[]
while(True):
	try:
		for f in friends['data']:
			f_id=f['id']
			profile=graph.get_object(id=f_id,fields='location')
			if profile.get(u'location'):
				locale_list.append(profile.get(u'location'))
				i=i+1
		friends=requests.get(friends['paging']['next']).json()
	except KeyError:
		break
locations=[]
for j in range(0,i):
	locations.append(locale_list[j].get(u'name'))
locations.sort()
count=Counter(locations)
plt.pie(count.values(),labels=set(locations))
plt.title('Chart depicting location of friends')
plt.show()
