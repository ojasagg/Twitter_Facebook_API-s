import matplotlib.pyplot as plt
import json
import facebook
import requests

ids='829823777051690'  
token='use own'
graph=facebook.GraphAPI(token)
a=[]
b=[]

friends=graph.get_connections(id='me',connection_name='friends')
while(True):
	try:
		for f in friends['data']:
			friend_id=f['id']
			frnd_prop=graph.get_object(id=friend_id,fields='name,languages')
			while(True):
				try:
					if frnd_prop.get(u'languages'):	
						for l in frnd_prop['languages']:
							lng=l['name']
							if lng in a:
								i=0
								for v in a:
									if v==lng:
										pos=i
									else:
										i=i+1
								b[pos]=b[pos]+1
							else:
								a.append(lng)
								b.append(1)
					frnd_prop=requests.get(frnd_prop['paging']['next']).json()
				except KeyError:
					break
		friends=requests.get(friends['paging']['next']).json
	except KeyError:
		break
plt.pie(b,labels=a)
plt.title('Chart depicting languages known by friends of a users')
plt.show()
