import matplotlib.pyplot as plt
import json
import facebook
import requests
import nltk
from nltk.probability import FreqDist
import matplotlib
import matplotlib.pyplot as plt
from itertools import groupby

token='use own'
graph=facebook.GraphAPI(token)
friends=graph.get_connections(id='me',connection_name='friends')
i=0
locale_list=[]
while(True):
	try:
		for f in friends['data']:
			f_id=f['id']
			profile=graph.get_object(id=f_id,fields='birthday')
			if profile.get(u'birthday'):
				locale_list.append(profile.get(u'birthday'))
				i=i+1
		friends=requests.get(friends['paging']['next']).json()
	except KeyError:
		break
bdays=[]
for j in range(0,i):
	mnth=locale_list[j]
	bdays.append(mnth[:2])
op=FreqDist(bdays)
op.plot(12,title='Time series graph of Month vs Number of Birthdays in that month')
